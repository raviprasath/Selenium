package firstday;

public class ControlFlowIfElseIfElse {

	public static void main(String[] args) {
		int age = 25;
		
		if (age <=24)
		{
			System.out.println("The given age is less than 25");
		}
		else if(age>=26) 
		{
			System.out.println("The given age is greater than 25");
		}	
		else if(age==25)
		{
			System.out.println("The given age is 25");

		}
		else
		{
			System.out.println("The given age is not statisfied the above conditions!!");
		}

	}

}
