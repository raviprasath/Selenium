package firstday;

public class ControlFlowIf {

	public static void main(String[] args) {
		int  a=5;

		if(a==6)
		{
			System.out.println("The given input number "+a+" is equal too 5");	
		}
		else
		{
			System.out.println("The given number is not equal to 5");
		}
	}

}
