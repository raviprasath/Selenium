package week1day2homework;

public class LogicalOperators {

	public static void main(String[] args) {
		int a=5;
		int b=7;

		if(a>=b)
			System.out.println("a is greater than b");

		if(a<=b)
			System.out.println("b is greater than a");

		if(a!=b)
			System.out.println("a is not equal to b");
	}

}
