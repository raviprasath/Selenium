package week5day1;

import org.junit.Test;
import org.openqa.selenium.WebElement;

import wdMethods.ProjectMethod;

public class EditLead1 extends ProjectMethod
{
	@Test
 public void editlead1() {

	login();
	click(locateElement("link", "CRM/SFA"));
	WebElement leads = locateElement("link", "Leads");
	click(leads); 	
	WebElement findLeads = locateElement("class","selected");
	click(findLeads);
	type(locateElement("id", "ext-gen248"), "Ranjith");
	type(locateElement("id", "ext-gen250"), "Babu");
	type(locateElement("id", "ext-gen252"), "SQS");
	WebElement findLead = locateElement("id", "ext-gen892");
	click(findLead);
	closeBrowser();
}
}