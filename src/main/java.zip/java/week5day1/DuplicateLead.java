package week5day1;

import org.testng.annotations.Test;

import wdMethods.ProjectMethod;

public class DuplicateLead extends ProjectMethod {
@Test
	public void duplicatelead() {
		login();
	    click(locateElement("link", "CRM/SFA"));
	    closeAllBrowsers();
	    
	}

}
