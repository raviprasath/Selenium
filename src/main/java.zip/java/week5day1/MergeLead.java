package week5day1;

import org.testng.annotations.Test;

public class MergeLead {
	@Test(enabled=false)
	public void mergelead() {
	System.out.println("Merge Lead");
	}

}
