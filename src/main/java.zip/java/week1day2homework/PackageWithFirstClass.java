package week1day2homework;

public class PackageWithFirstClass {

	public static void main(String[] args) {
		
		System.out.println("First Class");
	}

}

/*Hi SSP- Posting the List of homeworks of Week1Day2

1)Write a program for Logical and Increament,Decreament operator.
2)Try creating more than 1 class in the same java file.
3)Explore Foreach loop over a collection of Strings(Names of 10 people) and print the gender of each person(Use Switch case)
4)Explore Foreach loop and Iterate over an Array of marks of 10 subjects & find out the pass(>=35) and Fail(<35).
5)Create a classA with 2 integers(int a,int b) and 4 methods[int add(int a,int b)-->add,sub,mul & div];
 Create a classB,create an object of classA,call the 4 methods using the object created.
6)Explore difference between heap memory and stack memory in java

7)Explore and find 5 new methods in String class.
8)Explore different methods in Scanner class to read a float,double,char from user.
9)Explore static method in Integer class(by creating multiple method)
10)Explore Access modifiers at package level.
11)Explore Access modifiers at Class level.(create Package A-->Class A and Class B)(Package B-->Class P and Class Q)
12)Explore Access modifiers at Method and variable level. 

//Trying to create second class within same package

private class PackageWithSecondClass{
	//Link all references for a local rename (does not change references in other files) --> Error for second class
	public static void main(String[] args)
	{
		System.out.println("Second Class");
	}
	}
	*/	