package firstday;

public class ControlFlowIfElse {

	public static void main(String[] args) {
		int  a=3;

		if(a==5)
		{
			System.out.println("The given input number "+a+" is equal too 5");	
		}
		else
		{
			System.out.println("The given input number "+a+" is not equal too 5");
		}
	}

}
