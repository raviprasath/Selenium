package week4homework;

public class Vehicle {
	
	void speed(){
		System.out.println("Vehicle");

	} 

}
