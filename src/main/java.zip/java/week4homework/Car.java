package week4homework;

public class Car extends Vehicle {
	
	void speed1() {
		System.out.println("Car");
	}

}
