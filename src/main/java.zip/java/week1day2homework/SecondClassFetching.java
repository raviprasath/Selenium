package week1day2homework;

public class SecondClassFetching {

	public static void main(String[] args) {
		
		FirstClassInput classObject = new FirstClassInput();
		
		classObject.addingNumber(5, 4);
		classObject.subtractNumber(5, 4);
		classObject.multiplyNumber(5, 4);
		classObject.divisionNumber(5, 4);
		
	}

}
