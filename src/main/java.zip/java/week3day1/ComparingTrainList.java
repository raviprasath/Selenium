package week3day1;

import java.util.List;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;

public class ComparingTrainList {
	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://erail.in");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement fromStation = driver.findElementById("txtStationFrom");
		fromStation.clear();
		fromStation.sendKeys("MAS");
		WebElement toStation = driver.findElementById("txtStationTo");
		toStation.clear();
		toStation.sendKeys("SBC");
		driver.findElementById("buttonFromTo").click();
		
 List<WebElement> trainList = driver.findElementsByXPath("//div[@id='divTrainsListHeader']/table/tbody/tr/td[2]");
System.out.println("No of column is "+trainList.size());

//div[@id="divTrainsList"]/table[1]/tbody/tr[1]/td[2]/a

//
//		for (WebElement list: trainList)
//		{
//			String trainListName = list.getText();
//			System.out.println("The train lists are: "+trainListName);
//		}
driver.close();	
		/*
		TreeSet<String> train  = new TreeSet<String>(trainNames);
		add(trainNames);
		
		List<WebElement> trainList = driver.findElementByXPath("//a[text()='Train Name']");
		for(WebElement trainListName : trainList)
		{
			String trainNameValue = trainListName.getText();
			System.out.println("Chennai to Bangalore available train lists are: "+trainNameValue);
		}

		driver.findElementByXPath("//a[text()='Train Name']").click();
		List<WebElement> trainList1 = driver.findElementByXPath("//a[text()='Train Name']");
		for(WebElement trainListName1 : trainList1)
		{
			String trainNameValue1 = trainListName1.getText();
			System.out.println("Chennai to Bangalore available train lists are: "+trainNameValue1);
		}	

		if(trainList.equals(trainList1))
			System.out.println("Both the list are same");
		else
			System.out.println("Both the list are not same");

		driver.close();
	}

	private static void add(String trainNames) {
		// TODO Auto-generated method stub
		 
		 */
		
	}
}
