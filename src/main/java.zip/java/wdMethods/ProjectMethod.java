package wdMethods;

import org.openqa.selenium.WebElement;

public class ProjectMethod extends SeMethods {
	
	public void login() {
		startApp("chrome","http://leaftaps.com/opentaps");
	 	WebElement userName = locateElement("id", "username");
	 	type(userName, "DemoSalesManager");
	 	WebElement passWord = locateElement("id", "password");
	 	type(passWord, "crmsfa");
	 	WebElement login = locateElement("class", "decorativeSubmit");
	 	click(login);
	}

}
