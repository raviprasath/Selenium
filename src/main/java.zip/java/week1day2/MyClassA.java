package week1day2;

public class MyClassA {

	int age;
	String name;

	int displayFriendAge()
	{
		System.out.println(age);
		return age;
	}

	String displayFriendName()
	{
		System.out.println(name);
		return name;

	}
}
