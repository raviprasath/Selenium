package firstday;

public class VariableTry {

	public static void main(String[] args) {
		String name = "Raviprasath";
		char initial = 'R';
		int age=25;
		long mobileNumber = 8695473343l;
		float height=171.77f;
		double weight=75.76;
		boolean maritalStatus = false;
		String[] myFavGames = {"Cricket","TT","Carrom"};
		System.out.println("Testleaf traiee details are below");
		System.out.println("Trainee name is "+name);
		System.out.println("Trainee initial is "+initial);
		System.out.println("Trainee age is "+age);
		System.out.println("Trainee mobile number is "+mobileNumber);
		System.out.println("Trainee height is "+height);
		System.out.println("Trainee weight is "+weight);
		System.out.println("Trainee marriage status is "+maritalStatus);
		System.out.println("Trainee favrite game is "+myFavGames[2]);
		

	}

}
