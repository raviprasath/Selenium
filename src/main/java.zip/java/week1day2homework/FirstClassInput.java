package week1day2homework;

public class FirstClassInput {
	int a,b;
	
	void addingNumber(int a, int b)
	{		
	System.out.println("Addition of a and b is "+(a+b));
	}
	
	void subtractNumber(int a, int b)
	{		
	System.out.println("Subtraction of a and b is "+(a-b));
	}
	
	void multiplyNumber(int a, int b)
	{		
	System.out.println("Multiplication of a and b is "+(a*b));
	}
	
	void divisionNumber(int a, int b)
	{		
	System.out.println("Division of a and b is "+(a/b));
	}
	
	
}