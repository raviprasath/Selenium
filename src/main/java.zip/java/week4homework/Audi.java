package week4homework;

public class Audi extends Car{

	public static void main(String arg[]) {
		Audi one = new Audi();
		one.speed();
		one.speed1();
	System.out.println("Audi");
	}
}
